package com.upgrad.quora.service.type;
//Enum for various actions for question and answer

public enum ActionType {

    EDIT_QUESTION, DELETE_QUESTION, CREATE_QUESTION, ALL_QUESTION, ALL_QUESTION_FOR_USER,
    EDIT_ANSWER, DELETE_ANSWER, CREATE_ANSWER, GET_ALL_ANSWER_TO_QUESTION, GET_USER_DETAILS, DELETE_USER;

}

