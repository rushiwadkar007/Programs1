function detailPosts () {
    location.href="./post.html";
}