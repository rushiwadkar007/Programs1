function listPosts () {
    location.href="./html/bloglist.html";
}